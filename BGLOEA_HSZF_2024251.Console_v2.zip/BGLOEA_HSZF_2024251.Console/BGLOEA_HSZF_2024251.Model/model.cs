﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Newtonsoft.Json;

namespace BGLOEA_HSZF_2024251.Model
{


    //-------------- json deserialized objects -------------------
    public class f1Teams
    {
        public f1Teams(string teamName, int year, string headquarters, string teamPrincipal, int constructorsChampionshipWins, Budget budget)
        {
            this.teamNameID = Guid.NewGuid().ToString();
            this.teamName = teamName;
            this.year = year;
            this.headquarters = headquarters;
            this.teamPrincipal = teamPrincipal;
            this.constructorsChampionshipWins = constructorsChampionshipWins;
            this.budget = budget;
        }

        public f1Teams()
        {
              
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int tnID { get; set; }
        public string teamNameID { get; set; }
        public string teamName { get; set; }
        public int year { get; set; }
        public string headquarters { get; set; }
        public string teamPrincipal { get; set; }
        public int constructorsChampionshipWins { get; set; }
        public virtual Budget budget { get; set; }


    }

    public class Budget
    {
        public Budget(int totalBudget, Expens[] expenses)
        {
            this.totalBudget = totalBudget;
            this.expenses = expenses;
            this.bID = Guid.NewGuid().ToString();
            this.expenses = new HashSet<Expens>();
        }

        public Budget()
        {
                
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int budgetID { get; set; }

        public string bID { get; set; }
        public int totalBudget { get; set; }
        public virtual ICollection<Expens> expenses { get; set; }
    }

    public class Expens
    {
        public Expens(string category, int amount, string approvalStatus, string expenseDate, Subcategory[] subcategory)
        {
            this.category = category;
            this.amount = amount;
            this.approvalStatus = approvalStatus;
            this.expenseDate = expenseDate;
            this.subcategory = subcategory;
            this.eID = Guid.NewGuid().ToString();
            this.subcategory = new HashSet<Subcategory>();
        }

        public Expens()
        {
                
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int expensID { get; set; }

        public string eID { get; set; }
        public string category { get; set; }
        public int amount { get; set; }
        public string approvalStatus { get; set; }
        public string expenseDate { get; set; }
        public virtual ICollection<Subcategory> subcategory { get; set; }
    }

    public class Subcategory
    {
        public Subcategory(string name, int amount)
        {
            this.name = name;
            this.amount = amount;
            this.scID = Guid.NewGuid().ToString();
        }

        public Subcategory()
        {
                
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int subcategoryID { get; set; }

        public string scID { get; set; }
        public string name { get; set; }
        public int amount { get; set; }
    }
}
