﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BGLOEA_HSZF_2024251.Model;
using Microsoft.EntityFrameworkCore;

namespace BGLOEA_HSZF_2024251.Persistance.MsSql
{
    public class DBContext : DbContext
    {
        public DbSet<f1Teams> Rootobjects { get; set; }

        public DBContext()
        {
            this.Database.EnsureDeleted();
            this.Database.EnsureCreated();
        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Test1;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            optionsBuilder.UseSqlServer(conn);

           /* conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=budget;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            optionsBuilder.UseSqlServer(conn);

            conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=expenses;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            optionsBuilder.UseSqlServer(conn);

            conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=subcategory;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            optionsBuilder.UseSqlServer(conn);*/

            base.OnConfiguring(optionsBuilder);
        }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }


    }
}
