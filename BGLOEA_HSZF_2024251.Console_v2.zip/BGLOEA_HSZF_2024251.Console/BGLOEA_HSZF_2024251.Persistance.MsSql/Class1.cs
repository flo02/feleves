﻿namespace BGLOEA_HSZF_2024251.Persistance.MsSql
{
    public class Class1
    {

    }
}
