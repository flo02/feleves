﻿namespace BGLOEA_HSZF_2024251.Test
{
    public class Class1
    {

    }
}
