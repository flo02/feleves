﻿namespace BGLOEA_HSZF_2024251.Model
{
    public class Class1
    {

    }
}
