﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace BGLOEA_HSZF_2024251.Model
{
    public class serialize
    {
        public static List<f1Teams> jsonSerialisation(string path)
        {
            List<f1Teams> f1 = JsonConvert.DeserializeObject<List<f1Teams>>(File.ReadAllText(path));
            return f1;

        }
    }
}
