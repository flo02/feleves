﻿using BGLOEA_HSZF_2024251.Model;
using BGLOEA_HSZF_2024251.Persistance.MsSql;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Newtonsoft.Json;


DBContext dBContext = new DBContext();


List<f1Teams> alma = serialize.jsonSerialisation(@"data.json");


foreach (var f1T in alma)
{
    dBContext.Add(f1T);
}

;