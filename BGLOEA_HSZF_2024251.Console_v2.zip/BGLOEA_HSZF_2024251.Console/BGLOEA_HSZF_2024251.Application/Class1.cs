﻿namespace BGLOEA_HSZF_2024251.Application
{
    public class Class1
    {

    }
}
